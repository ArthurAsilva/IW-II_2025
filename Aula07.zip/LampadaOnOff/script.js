const lampada = document.getElementById("lampada");
const btnLigar = document.getElementById("ligar");
const btnDesligar = document.getElementById("desligar");
const btnQuebrar = document.getElementById("quebrar");

function estaQuebrada() {
  return lampada.src.includes("quebrada");
}

function ligarLampada() {
  if (!estaQuebrada()) {
    lampada.src = "https://i.imgur.com/9bX6fWQ.png";
    lampada.alt = "Lâmpada Ligada";
  }
}

function desligarLampada() {
  if (!estaQuebrada()) {
    lampada.src = "https://i.imgur.com/1kX1Kcb.png";
    lampada.alt = "Lâmpada Desligada";
  }
}

function quebrarLampada() {
  lampada.src = "https://i.imgur.com/O9bFZWs.png";
  lampada.alt = "Lâmpada Quebrada";
}

btnLigar.addEventListener("click", ligarLampada);
btnDesligar.addEventListener("click", desligarLampada);
btnQuebrar.addEventListener("click", quebrarLampada);
