const imagem = document.getElementById("minhaImagem");

function trocarImagem(numero) {
  const imagens = {
    1: "imagens/img1.jpg",
    2: "imagens/img2.jpg",
    3: "imagens/img3.jpg"
  };
  imagem.src = imagens[numero];
}
